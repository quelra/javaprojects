public interface Encryptable{
    public void encrypt();
    public String decrypt();
} //end of Encryptable interface


