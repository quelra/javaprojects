

import converter.ConversionPOA;

class ConversionServant extends ConversionPOA {

    @Override
    public double convertToInch(double cm) {
        return cm/2.54;
    }

    @Override
    public double convertToCm(double inch) {
        return inch*2.54;
    }
}